rings = [[C16, C17, C18, C19, C20, N26], [C21, C22, C23, C24, N27]]
non_ring_pi_bonds = []
