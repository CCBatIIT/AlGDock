rings = [[C12, C13, C14, C15, C16, C17]]
non_ring_pi_bonds = [Bond(C18, O22), Bond(C18, O23)]
